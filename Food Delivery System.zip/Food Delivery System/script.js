// =====================================================
// CLOUD EATS - CLOUD FOOD DELIVERY SYSTEM
// JavaScript + Firebase Firestore
// =====================================================


// =====================================================
// FIREBASE IMPORTS
// =====================================================

import { initializeApp }
    from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
    getFirestore,
    collection,
    addDoc,
    getDocs
}
    from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


// =====================================================
// FIREBASE CONFIGURATION
// =====================================================
//
// IMPORTANT:
// Replace the values below with YOUR Firebase
// configuration from Firebase Console.
//
// Firebase Console
// → Project Settings
// → General
// → Your Apps
// → Web App
// → SDK setup and configuration
// → Config
//
// =====================================================

const firebaseConfig = {

    apiKey: "YOUR_API_KEY",

    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",

    projectId: "YOUR_PROJECT_ID",

    storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",

    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",

    appId: "YOUR_APP_ID"

};


// =====================================================
// CONNECT TO FIREBASE
// =====================================================

const app = initializeApp(firebaseConfig);


// Connect to Firestore Database

const db = getFirestore(app);


// =====================================================
// CART
// =====================================================

let cart = [];


// =====================================================
// ADD FOOD TO CART
// =====================================================

window.addToCart = function (foodName, foodPrice) {

    cart.push({

        name: foodName,

        price: foodPrice

    });

    displayCart();

};


// =====================================================
// DISPLAY CART
// =====================================================

function displayCart() {

    const cartItems =
        document.getElementById("cartItems");

    const total =
        document.getElementById("total");


    // Safety check

    if (!cartItems || !total) {

        console.error(
            "Cart elements not found in HTML."
        );

        return;

    }


    // Clear old cart

    cartItems.innerHTML = "";


    let totalAmount = 0;


    // Empty cart

    if (cart.length === 0) {

        cartItems.innerHTML = `
            <p>🛒 Your cart is empty.</p>
        `;

        total.innerText = "0";

        return;

    }


    // Display every item

    cart.forEach(function (item, index) {

        totalAmount =
            totalAmount + item.price;


        cartItems.innerHTML += `

            <div class="cart-item">

                <span>
                    ${item.name}
                    - ₹${item.price}
                </span>

                <button
                    onclick="removeItem(${index})">

                    Remove

                </button>

            </div>

        `;

    });


    // Display total

    total.innerText = totalAmount;

}


// =====================================================
// REMOVE ITEM FROM CART
// =====================================================

window.removeItem = function (index) {

    cart.splice(index, 1);

    displayCart();

};


// =====================================================
// PLACE ORDER
// =====================================================

window.placeOrder = async function () {

    console.log("Place Order button clicked");


    // Get HTML elements

    const nameInput =
        document.getElementById("name");

    const addressInput =
        document.getElementById("address");


    // Check if HTML elements exist

    if (!nameInput) {

        alert(
            "Error: Name input not found."
        );

        console.error(
            "HTML element #name is missing."
        );

        return;

    }


    if (!addressInput) {

        alert(
            "Error: Address input not found."
        );

        console.error(
            "HTML element #address is missing."
        );

        return;

    }


    // Get values

    const customerName =
        nameInput.value.trim();

    const deliveryAddress =
        addressInput.value.trim();


    // =================================================
    // VALIDATE NAME
    // =================================================

    if (customerName === "") {

        alert(
            "Please enter your name."
        );

        nameInput.focus();

        return;

    }


    // =================================================
    // VALIDATE ADDRESS
    // =================================================

    if (deliveryAddress === "") {

        alert(
            "Please enter your delivery address."
        );

        addressInput.focus();

        return;

    }


    // =================================================
    // VALIDATE CART
    // =================================================

    if (cart.length === 0) {

        alert(
            "Please add at least one food item to your cart."
        );

        return;

    }


    // =================================================
    // CALCULATE TOTAL
    // =================================================

    let totalAmount = 0;


    cart.forEach(function (item) {

        totalAmount =
            totalAmount + item.price;

    });


    // =================================================
    // CREATE ORDER
    // =================================================

    const order = {

        customerName: customerName,

        deliveryAddress: deliveryAddress,

        foodItems: cart,

        totalAmount: totalAmount,

        status: "Order Placed",

        orderTime:
            new Date().toLocaleString()

    };


    console.log(
        "Order data:",
        order
    );


    // =================================================
    // SAVE ORDER TO FIREBASE
    // =================================================

    try {

        console.log(
            "Connecting to Firebase..."
        );


        const ordersCollection =
            collection(db, "orders");


        const documentReference =
            await addDoc(
                ordersCollection,
                order
            );


        // =================================================
        // SUCCESS
        // =================================================

        console.log(
            "Order successfully saved:",
            documentReference.id
        );


        alert(
            "🎉 ORDER PLACED SUCCESSFULLY!\n\n" +

            "Customer: " +
            customerName +

            "\n\nTotal: ₹" +
            totalAmount +

            "\n\nOrder ID: " +
            documentReference.id
        );


        // =================================================
        // CLEAR CART
        // =================================================

        cart = [];

        displayCart();


        // =================================================
        // CLEAR CUSTOMER DETAILS
        // =================================================

        nameInput.value = "";

        addressInput.value = "";


        // =================================================
        // LOAD ORDERS AGAIN
        // =================================================

        loadOrders();

    }


    // =================================================
    // FIREBASE ERROR
    // =================================================

    catch (error) {

        console.error(
            "Firebase Error:",
            error
        );


        alert(
            "❌ ORDER NOT PLACED\n\n" +
            "Firebase Error:\n\n" +
            error.message
        );

    }

};


// =====================================================
// LOAD ORDERS FROM FIREBASE
// =====================================================

async function loadOrders() {

    const orderList =
        document.getElementById("orderList");


    // Check HTML element

    if (!orderList) {

        console.error(
            "Element #orderList not found."
        );

        return;

    }


    try {

        console.log(
            "Loading orders from Firebase..."
        );


        const ordersCollection =
            collection(db, "orders");


        const snapshot =
            await getDocs(
                ordersCollection
            );


        // Clear previous orders

        orderList.innerHTML = "";


        // =================================================
        // NO ORDERS
        // =================================================

        if (snapshot.empty) {

            orderList.innerHTML = `

                <p>
                    📦 No orders yet.
                </p>

            `;

            return;

        }


        // =================================================
        // DISPLAY ORDERS
        // =================================================

        snapshot.forEach(function (document) {

            const order =
                document.data();


            orderList.innerHTML += `

                <div class="order">

                    <h3>
                        📦 Order
                    </h3>


                    <p>
                        <strong>
                            Customer:
                        </strong>

                        ${order.customerName}
                    </p>


                    <p>
                        <strong>
                            Address:
                        </strong>

                        ${order.deliveryAddress}
                    </p>


                    <p>
                        <strong>
                            Food:
                        </strong>

                        ${getFoodNames(order.foodItems)}
                    </p>


                    <p>
                        <strong>
                            Total:
                        </strong>

                        ₹${order.totalAmount}
                    </p>


                    <p>
                        <strong>
                            Status:
                        </strong>

                        ${order.status}
                    </p>


                    <p>
                        <strong>
                            Time:
                        </strong>

                        ${order.orderTime}
                    </p>

                </div>

            `;

        });

    }


    catch (error) {

        console.error(
            "Error loading orders:",
            error
        );


        orderList.innerHTML = `

            <p>
                Unable to load orders.
            </p>

        `;

    }

}


// =====================================================
// GET FOOD NAMES
// =====================================================

function getFoodNames(items) {

    if (!items) {

        return "No food";

    }


    return items
        .map(function (item) {

            return item.name;

        })
        .join(", ");

}


// =====================================================
// GO TO MENU
// =====================================================

window.goToMenu = function () {

    const menu =
        document.getElementById("menu");


    if (menu) {

        menu.scrollIntoView({

            behavior: "smooth"

        });

    }

};


// =====================================================
// START APPLICATION
// =====================================================

displayCart();

loadOrders();


// =====================================================
// FIREBASE CONNECTION MESSAGE
// =====================================================

console.log(
    "☁️ CloudEats Firebase application started."
);